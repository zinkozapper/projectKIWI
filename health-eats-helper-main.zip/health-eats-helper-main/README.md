# Kiwi Nutrition

generate this as html and css

Problem Summary




Young adults between 18 and 28 want to eat healthy and hit basic nutritional targets, but they do not have the time or money for strict diets and complex tracking apps. Because they balance busy schedules and lack deep nutrition knowledge, they default to buying the same groceries their parents bought. At the same time, social media, friends, and family feed them confusing or inaccurate health trends. They are not trying to lose weight or build muscle, so intense calorie counting feels unnecessary. Prepping meals takes too much time, gets boring fast, and costs too much upfront. Above all, they prioritize convenience and just want simple, reliable ways to eat balanced meals at maintenance levels without having to overthink their food choices.




Scope

Must Have

Food suggestions (“pairs well with”)

Simplified weekly shopping list tracker instead of daily intake tracker

Nutrient profile of grocery list

Shopping list history

Creates an RDA profile based on user data

Should Have

Estimated budget of grocery trip

Suggest convenience options (canned instead of uncooked, rotisserie instead of frozen chicken)

Favorite meals / repeated meal section

Emphasizes common nutrient deficiencies based on user profile

Food nutrient look-up

Could Have

Gamify nutrient intake

Provide “eat out” alternatives

Recipe suggestions based on list

Shelf-life and expiration tracker

Won’t Have

Integration with local store inventories

Barcode scanning / photo meal logging

In-app purchasing and auto delivery

Wearable fitness device integration

Behavioral Requirements

Always apply - The system [does this].

The system calculates daily calorie and nutrient targets from user profile data.

The system displays running totals of macros and calories for all items in the list.

The system calculates average daily nutrient intake across the selected grocery trip duration.

The system displays the remaining macro and micro nutrient gap between list totals and user targets.

The system restricts list item quantities to positive numbers only.

Triggered - When [something happens], the system [specific response].

When the user adds a food from the database, the system updates the list with its nutritional values.

When the user adjusts trip frequency, the system updates total target calories and nutrients for that duration.

When current list totals fall below nutritional targets, the system suggests 2 whole foods to fill the gap.

When the user selects a food, the system shows 2 foods that pair well with it.

When an item currently on the list is checked off by the user, the system removes the item from the list.

Failure case

When required profile fields are left blank, the system prevents saving and flags the missing inputs.

When a user enters an invalid item quantity (e.g., zero or non-numeric), the system rejects the input and shows an error message.




AI Disclosure Statement–Gemini was used to:

Polish the wording of the summary statement




CHAT CONTENT:

Help me polish a summary paragraph for the following problem:




College-aged men and women (age 18-28) with a passive interest in their own health but lack of available resources typically adapt their grocery shopping patterns after their parents. The persona suffers from a colloquial understanding of health perpetuated by anecdotal presentations through social media, parents, friends, etc. The persona shys away from intense health tracking systems on account of general business but also differing goals, they're not trying to lose weight, they're not trying to build a lean physique, they just want to eat within a maintenance limit, get their nutrients (macro and micro). Convenience is the highest priority. Meal prepping is repetitive and expensive. Lacks awareness of the nutritional landscape. 




Young adults between 18 and 28 want to eat healthy and hit basic nutritional targets, but they do not have the time or money for strict diets and complex tracking apps. Because they balance busy schedules and lack deep nutrition knowledge, they default to buying the same groceries their parents bought. At the same time, social media, friends, and family feed them confusing or inaccurate health trends. They are not trying to lose weight or build muscle, so intense calorie counting feels unnecessary. Prepping meals takes too much time, gets boring fast, and costs too much upfront. Above all, they prioritize convenience and just want simple, reliable ways to eat balanced meals at maintenance levels without having to overthink their food choices.




Screen Descriptions




Screen 1

The first screen a user sees when they open Kiwi

Lets the user log in to their account quickly, or create one if they're new

Gives a clear choice between logging in and creating an account, with fields for username and password

Shows the Kiwi logo and name so users know they're in the right app

A wrong username or password shows a clear error message without clearing what they typed

Screen 2

Appears right after a user logs in for the first time

Lets the user tell Kiwi what food they already have at home, so recommendations start from what they own

Offers a quick way to pick common pantry items without typing each one

Adding items should take less than a minute

Users can skip this step or come back later, and an empty pantry doesn't stop them from moving on

Screen 3

Appears after the user sets up their pantry, before they plan a shopping trip

Shows how well the food they already have covers their nutritional needs, and what's missing

Breaks down macro and micronutrients in an easy-to-scan view of what's covered and what's low

Makes clear that the results come from their pantry

Gives a clear next step to plan a shopping trip that fills the gaps

If the pantry is empty or very small, says the snapshot is limited instead of showing misleading numbers

Screen 4

The main planning screen, reached from the nutrition snapshot or the home screen

Helps the user build a grocery list that fills their nutrition gaps without going over budget

Lets them search a food database and add items to their list

Shows a live nutrient profile that updates as items are added

Suggests foods that would close their biggest nutrition gaps

Previews how a suggestion would change their nutrients before they add it

If a search finds nothing, offers close matches

Suggestions respect the user's budget and health goals

Screen 5

Used in the store once the user has finished planning

Helps the user get through the store quickly without forgetting anything

A simple list they can check off item by item

Easy to read at a glance and use one-handed on a phone

Saves their progress if they leave the app

Screen 6

Reachable from anywhere through the user's profile, and ideally filled in early

Lets the user give Kiwi the personal details it needs for accurate, relevant recommendations

Fields for height, weight, and gender to set accurate nutrient targets

Lets them set a grocery budget and define health goals

Explains why each piece of information is needed

Flags values that look wrong, and goals can be updated at any time

Screen 7

Available to returning users from the planning screen or the main menu

Helps the user rebuild a grocery list quickly using items they buy often

Keeps a record of past and frequent purchases

A quick-add option sends any past item straight to the current list

New users with no history see a message explaining that this fills in over time

Screen 8

Appears while the user is building a grocery list, based on what they've added

Helps the user find affordable, convenient foods that go with what they already buy and improve their nutrition

Recommendations are based on their common purchases

Each suggestion briefly says why it's recommended: cheap, easy, or nutrient-dense

Suggestions stay within budget and don't repeat items already on the list or in the pantry

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/3ac2b1e8-de8b-5dff-a774-3196acc5a167).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
